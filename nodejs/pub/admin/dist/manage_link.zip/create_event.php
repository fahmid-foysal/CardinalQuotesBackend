<?php
session_start();

if (!isset($_SESSION["admin_id"])) {
   
    header("Location: login.php");
    exit;
}

?>


<!DOCTYPE html> 
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>Lotterybdt</title>
    <!-- Custom CSS -->
    <link href="assets/libs/flot/css/float-chart.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <a class="navbar-brand" href="index.html">
                        <!-- Logo icon -->
                        <b class="logo-icon p-l-10">
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            <!-- <img src="assets/images/logo-icon.png" alt="homepage" class="light-logo" /> -->
                           
                        </b>
                        <!--End Logo icon -->
                         <!-- Logo text -->
                        <span class="logo-text">
                             <!-- dark Logo text -->
                             <!-- <img src="assets/images/logo-text.png" alt="homepage" class="light-logo" /> -->
                            <H3 class="text-center p-t-20 p-b-20" >Lottery Bdt</H3>
                        </span>
                
                    </a>
                
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.html" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Dashboard</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="sold_coupon.php" aria-expanded="false"><i class="mdi mdi-ticket"></i><span class="hide-menu">Manage Cupon</span></a></li>
                       <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="widgets.html" aria-expanded="false"><i class="mdi mdi-cash"></i><span class="hide-menu">Manage Deposit</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="tables.html" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span class="hide-menu">Publish Result</span></a></li>   
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="create_event.php" aria-expanded="false"><i class="mdi mdi-arrow-all"></i><span class="hide-menu">Create Event</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="charts.html" aria-expanded="false"><i class="mdi mdi-link"></i><span class="hide-menu">Manage Live</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="charts.html" aria-expanded="false"><i class="mdi mdi-pencil"></i><span class="hide-menu">Manage sold coupon</span></a></li>
                        
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="charts.html" aria-expanded="false"><i class="mdi mdi-calendar-check"></i><span class="hide-menu">Manage Prize</span></a></li>
                       
                        <li class="sidebar-item"> 
                        <a class="sidebar-link waves-effect waves-dark sidebar-link" href="#" onclick="logout(); return false;" aria-expanded="false">
                            <i class="mdi mdi-logout"></i>
                            <span class="hide-menu">Logout</span>
                        </a>
                        </li>

                      
                    
                       
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
       <div class="page-wrapper bg-white">

          
           <div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="text-primary">Lottery Events</h4>
        <button class="btn btn-success" onclick="showPopup()">Create New Event</button>
    </div>
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>Event ID</th>
                    <th>Event Name</th>
                    <th>Start Coupon No</th>
                    <th>Last Coupon No</th>
                    <th>Draw Date</th>
                    <th>Draw time</th>
                    <th>Coupon Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="eventTableBody">
                
                <!-- Additional rows can be dynamically inserted here -->
            </tbody>
        </table>
    </div>
</div>

                        </div>
                    </div>
                </div>
            </div>
          
        </div>
 <!-- Create Event Modal -->
<div class="modal fade" id="createEventModal" tabindex="-1" aria-labelledby="createEventModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createEventModalLabel">Create New Event</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="createEventForm">
                    <div class="mb-3">
                        <label for="eventName" class="form-label">Event Name</label>
                        <input type="text" class="form-control" id="eventName" required pattern="^[a-zA-Z0-9\s\-_]+$" title="Only letters, numbers, spaces, -, and _ are allowed.">
                    </div>
                    <div class="mb-3">
                        <label for="startNum" class="form-label">Start Coupon No</label>
                        <input type="number" class="form-control" id="startNum" required min="1">
                    </div>
                    <div class="mb-3">
                        <label for="endNum" class="form-label">Last Coupon No</label>
                        <input type="number" class="form-control" id="endNum" required min="1">
                    </div>
                    <div class="mb-3">
                        <label for="drawDate" class="form-label">Draw Date</label>
                        <input type="date" class="form-control" id="drawDate" required>
                    </div>
                    <div class="mb-3">
                        <label for="drawtime" class="form-label">Draw time</label>
                        <input type="time" class="form-control" id="drawtime" required>
                    </div>
                    <div class="mb-3">
                        <label for="couponPrice" class="form-label">Coupon Price (BDT)</label>
                        <input type="number" class="form-control" id="couponPrice" required min="0.01" step="0.01">
                    </div>
                    <div class="mb-3">
                        <label for="bannerPath" class="form-label">Event Banner</label>
                        <input type="file" class="form-control" id="bannerPath" accept="image/*" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Create Event</button>
                </form>
            </div>
        </div>
    </div>
</div>

    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
    <!--This page JavaScript -->
    <!-- <script src="dist/js/pages/dashboards/dashboard1.js"></script> -->
    <!-- Charts js Files -->
    <script src="assets/libs/flot/excanvas.js"></script>
    <script src="assets/libs/flot/jquery.flot.js"></script>
    <script src="assets/libs/flot/jquery.flot.pie.js"></script>
    <script src="assets/libs/flot/jquery.flot.time.js"></script>
    <script src="assets/libs/flot/jquery.flot.stack.js"></script>
    <script src="assets/libs/flot/jquery.flot.crosshair.js"></script>
    <script src="assets/libs/flot.tooltip/js/jquery.flot.tooltip.min.js"></script>
    <script src="dist/js/pages/chart/chart-page-init.js"></script>
     <script>
         
                        $(document).ready(function () {
    fetchEvents(); // Load events when the page loads
});

function fetchEvents() {
    $.ajax({
        url: "https://www.lotterybdt.com/api/get_all_event.php", // Replace with your actual API endpoint
        type: "GET",
        success: function (response) {
            if (response.status === "success") {
                let events = response.events; // Assuming response has a 'data' key with an array of events
                let tableBody = $("#eventTableBody");
                tableBody.empty(); // Clear existing table data

                events.forEach(event => {
                    let row = `
                        <tr data-event-id="${event.id}">
                            <td>${event.id}</td>
                            <td>${event.event_name}</td>
                            <td>${event.start_num}</td>
                            <td>${event.end_num}</td>
                            <td>${event.draw_date}</td>
                            <td>${event.draw_time}</td>
                            <td>${event.coupon_price} BDT</td>
                            <td>
                               <button class="btn btn-warning btn-sm">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteRow(this)">Delete</button>
                            </td>
                        </tr>
                    `;
                    tableBody.append(row);
                });
            } else {
                alert("Error: " + response.message);
            }
        },
        error: function (xhr) {
            console.log(xhr.responseText);
            alert("Failed to load events.");
        }
    });
}

 function logout() {
    if (confirm("Are you sure you want to logout?")) {
        $.ajax({
            url: "https://www.lotterybdt.com/api/admin_logout.php",
            type: "POST",
            contentType: "application/json",
            success: function(response) {
                if (response.status === "success") {
                    alert("Logout successful!");
                    window.location.href = "login.php";
                } else {
                    alert("Logout failed: " + response.message);
                }
            },
            error: function(xhr) {
                alert("Error: " + xhr.responseText);
            }
        });
    }
}


function showPopup() {
    $('#createEventModal').modal('show');
}

$(document).ready(function () {
    $("#createEventForm").submit(function (e) {
        e.preventDefault();

        let eventName = $("#eventName").val().trim();
        let startNum = parseInt($("#startNum").val());
        let endNum = parseInt($("#endNum").val());
        let drawDate = $("#drawDate").val();
        let drawtime = $("#drawtime").val();
        let formattedTime = drawtime + ":00";
        let couponPrice = parseFloat($("#couponPrice").val());
        let bannerFile = $("#bannerPath")[0].files[0]; // Get the uploaded file

        // Input validation before sending the request
        if (!eventName || !startNum || !endNum || !drawDate || !couponPrice || !bannerFile) {
            alert("All fields are required, including the event banner.");
            return;
        }
        if (startNum <= 0 || endNum <= 0 || couponPrice <= 0) {
            alert("Start number, End number, and Coupon price must be positive values.");
            return;
        }
        if (startNum >= endNum) {
            alert("Start number must be less than End number.");
            return;
        }

        let formData = new FormData();
        formData.append("event_name", eventName);
        formData.append("start_num", startNum);
        formData.append("end_num", endNum);
        formData.append("draw_date", drawDate);
        formData.append("draw_time", formattedTime);
        formData.append("coupon_price", couponPrice);
        formData.append("banner_path", bannerFile); // Attach the file

        $.ajax({
            url: "https://www.lotterybdt.com/api/create_event.php",
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                if (response.status === "success") {
                    alert("Event created successfully!");
                    $("#createEventModal").modal('hide');
                    location.reload(); // Refresh to see new event
                } else {
                    alert("Error: " + response.message);
                }
            },
            error: function (xhr) {
                alert("Request failed: " + xhr.responseText);
            }
        });
    });
});

function deleteRow(button) {
    let row = button.closest("tr"); // Find the closest table row
    let eventId = row.getAttribute("data-event-id"); // Get event ID from data attribute

    if (!eventId || isNaN(eventId)) {
        alert("Invalid Event ID.");
        return;
    }

    if (!confirm("Are you sure you want to delete this event?")) {
        return; // Cancel deletion if the user clicks 'Cancel'
    }

    $.ajax({
        url: `https://www.lotterybdt.com/api/delete_event.php?event_id=${eventId}`,
        type: "DELETE",
        success: function (response) {
            console.log(response);
            if (response.status === "success") {
                alert("Event deleted successfully!");
                row.remove(); // Remove the row from the table
            } else {
                alert("Error: " + response.message);
            }
        },
        error: function (xhr) {
            console.log(xhr.responseText);
            alert("Request failed: " + xhr.responseText);
        }
    });
}

     </script>
  


</body>

</html>