<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lotterybdt - Sold Coupons</title>
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <link href="assets/libs/flot/css/float-chart.css" rel="stylesheet">
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jsPDF & AutoTable for PDF generation -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>
</head>

<body>
    <div id="main-wrapper">
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <a class="navbar-brand" href="index.html">
                        <h3 class="text-center p-t-20 p-b-20">Lottery Bdt</h3>
                    </a>
                </div>
            </nav>
        </header>

        <aside class="left-sidebar" data-sidebarbg="skin5">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">
                        <li class="sidebar-item"> <a class="sidebar-link" href="index.html"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Dashboard</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link" href="sold_coupon.php"><i class="mdi mdi-ticket"></i><span class="hide-menu">Manage Coupon</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link" href="create_event.php"><i class="mdi mdi-arrow-all"></i><span class="hide-menu">Create Event</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link" href="#" onclick="logout(); return false;"><i class="mdi mdi-logout"></i><span class="hide-menu">Logout</span></a></li>
                    </ul>
                </nav>
            </div>
        </aside>

        <div class="page-wrapper bg-white">
            <div class="container mt-4">
                <h4 class="text-primary">All Sold Coupons</h4>
                <div class="mb-3">
                    <div class="input-group" style="max-width: 300px;">
                        <span class="input-group-text bg-primary text-white"><i class="mdi mdi-magnify"></i></span>
                        <input type="text" id="searchCoupon" class="form-control border-primary shadow-sm" placeholder="Search by Coupon..." onkeyup="searchCoupon()">
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th>Coupon No</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="eventTableBody">
                            <!-- Dynamic content will be inserted here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery & Bootstrap JS -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>

    <script>
        $(document).ready(function () {
            fetchSoldCoupons();
        });

        function fetchSoldCoupons() {
            $.ajax({
                url: "https://www.lotterybdt.com/api/get_all_sold_coupons.php",
                type: "GET",
                success: function (response) {
                    if (response.status === "success") {
                        let coupons = response.purchased_coupons;
                        let groupedEvents = {};

                        coupons.forEach(coupon => {
                            if (!groupedEvents[coupon.event_id]) {
                                groupedEvents[coupon.event_id] = {
                                    event_name: coupon.event_name,
                                    coupons: []
                                };
                            }
                            groupedEvents[coupon.event_id].coupons.push(coupon);
                        });

                        let tableBody = $("#eventTableBody");
                        tableBody.empty();

                        for (const eventId in groupedEvents) {
                            let event = groupedEvents[eventId];

                            let eventHeader = `
                                <tr class="table-primary">
                                    <td colspan="3"><strong>${event.event_name}</strong></td>
                                    <td><button class="btn btn-success btn-sm generate-pdf" data-event='${JSON.stringify(event)}'>Generate PDF</button></td>
                                </tr>
                            `;
                            tableBody.append(eventHeader);

                            event.coupons.forEach(coupon => {
                                let row = `
                                    <tr>
                                        <td>${coupon.coupon_number}</td>
                                        <td>${coupon.name}</td>
                                        <td>${coupon.phone}</td>
                                        <td></td>
                                    </tr>
                                `;
                                tableBody.append(row);
                            });
                        }

                        // Attach event listener after rendering
                        $(".generate-pdf").off("click").on("click", function () {
                            let eventData = JSON.parse($(this).attr("data-event"));
                            generatePDF(eventData.event_name, eventData.coupons);
                        });

                    } else {
                        alert("Error: " + response.message);
                    }
                },
                error: function () {
                    alert("Failed to load sold coupons.");
                }
            });
        }

        function searchCoupon() {
            let couponNumber = $("#searchCoupon").val().trim();
            let tableBody = $("#eventTableBody");

            if (couponNumber === "") {
                fetchSoldCoupons();
                return;
            }

            $.ajax({
                url: `https://www.lotterybdt.com/api/search_by_coupon.php?coupon_number=${couponNumber}`,
                type: "GET",
                success: function (response) {
                    tableBody.empty();

                    if (response.status === "success" && response.data) {
                        let data = response.data;
                        let eventHeader = `
                            <tr class="table-primary">
                                <td colspan="3"><strong>${data.event_name}</strong></td>
                                <td></td>
                            </tr>
                        `;
                        tableBody.append(eventHeader);

                        let row = `
                            <tr>
                                <td>${couponNumber}</td>
                                <td>${data.user_name || "N/A"}</td>
                                <td>${data.user_phone || "N/A"}</td>
                                <td></td>
                            </tr>
                        `;
                        tableBody.append(row);
                    } else {
                        tableBody.html('<tr><td colspan="4" class="text-center text-danger">No matching coupons found.</td></tr>');
                    }
                },
                error: function () {
                    tableBody.html('<tr><td colspan="4" class="text-center text-danger">Error fetching data. Try again.</td></tr>');
                }
            });
        }

function generatePDF(eventName, coupons) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.setFontSize(16);
    doc.text(`Sold Coupons for ${eventName}`, 20, 10);
    doc.setFontSize(12);

    let yPos = 30; // Starting Y position
    const leftX = 20;   // Left column X position
    const rightX = 115; // Right column X position

    coupons.forEach((coupon, index) => {
        // Determine if left or right column
        const isLeft = index % 2 === 0;
        const xPos = isLeft ? leftX : rightX;

        // Add coupon info
        doc.text(`Coupon: ${coupon.coupon_number}`, xPos, yPos);
        doc.text(`Name:   ${coupon.name}`, xPos, yPos + 7);
        doc.text(`Phone:  ${coupon.phone}`, xPos, yPos + 14);

        // Draw horizontal line under each coupon
        doc.line(xPos, yPos + 18, xPos + 80, yPos + 18);

        // After two coupons, move to the next row
        if (!isLeft) {
            yPos += 28; // Space for the next row
        }

        // Draw vertical line in the middle after first coupon
        if (isLeft && (index < coupons.length - 1)) {
            doc.line(105, yPos - 10, 105, yPos + 10); // Middle line
        }

        // Add new page if content exceeds the bottom margin
        if (yPos > 270) {
            doc.addPage();
            yPos = 30;
        }
    });

    doc.save(`${eventName}_sold_coupons.pdf`);
}



    </script>
</body>

</html>
