<?php
session_start();

if (!isset($_SESSION["admin_id"])) {
    header("Location: login.php"); // Redirect to login page
    exit;
}
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Banners</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="text-primary">Available Banners</h4>
            <button class="btn btn-success" onclick="showPopup()">Upload Banner</button>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered text-center">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Banner Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="BannerTableBody"></tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="uploadBannerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Upload Banner</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="uploadBannerForm">
                        <div class="mb-3">
                            <label class="form-label">Banner Image</label>
                            <input type="file" class="form-control" id="banner_image" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Upload</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(fetchBanners);

       function fetchBanners() {
    $.ajax({
        url: "https://www.lotterybdt.com/api/get_all_slider.php",
        type: "GET",
        success: function (response) {
            if (response.status === "success") {
                let tableBody = $("#BannerTableBody");
                tableBody.empty();
                response.sliders.forEach((banner, index) => {
                    let row = `
                        <tr>
                            <td>${index + 1}</td>  <!-- Serial Number Starts from 1 -->
                            <td><img src="${banner.image_url}" width="150"></td>
                            <td>
                                <button class="btn btn-danger btn-sm" onclick="deleteBanner(${banner.id})">Delete</button>
                            </td>
                        </tr>
                    `;
                    tableBody.append(row);
                });
            }
        },
        error: function () {
            console.error("Error fetching banners.");
        }
    });
}


        function showPopup() {
            $('#uploadBannerModal').modal('show');
        }

        $("#uploadBannerForm").submit(function (e) {
            e.preventDefault();
            let formData = new FormData();
            formData.append("image", $("#banner_image")[0].files[0]);
            
            $.ajax({
                url: "https://www.lotterybdt.com/api/upload_slider.php",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.status === "success") {
                        alert("Banner uploaded successfully!");
                        $('#uploadBannerModal').modal('hide');
                        fetchBanners();
                    } else {
                        alert("Error: " + response.message);
                    }
                },
                error: function () {
                    alert("Failed to upload banner.");
                }
            });
        });

     function deleteBanner(bannerId) {
    if (!confirm("Are you sure you want to delete this banner?")) return;
    $.ajax({
        url: `https://www.lotterybdt.com/api/delete_slider.php?slider_id=${bannerId}`,
        type: "DELETE",
        success: function (response) {
            console.log(response);
            if (response.status === "success") {
                alert("Slider image deleted successfully!");
                fetchBanners();
            } else {
                alert("Error: " + response.message);
            }
        },
        error: function (xhr, status, error) {
            console.error("Delete Error:", xhr.responseText);
            alert("Failed to delete slider image.");
        }
    });
}


    </script>
</body>
</html>