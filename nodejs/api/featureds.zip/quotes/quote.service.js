const pool = require("../../config/database");

module.exports = {
    create: (data, callBack) => {
        pool.query(
            'INSERT INTO quotes (is_text, quote, category) VALUES (?, ?, ?)',
            [data.is_text, data.quote, data.category],
            (error, results) => {
                if (error) {
                    return callBack(error);
                }
                return callBack(null, results);
            }
        );
    },
    
    quotesByCategory: (category, callBack) => {
        pool.query(
            'SELECT id, quote, is_text FROM quotes WHERE category = ?',
            [category],
            (error, results) => {
                if (error) {
                    return callBack(error);
                }
                return callBack(null, results);
            }
        );
    }
};