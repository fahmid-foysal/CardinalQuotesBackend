const pool = require("../../config/database");

module.exports = {
  create: (data, callBack) => {
    pool.query(
      'INSERT INTO featured (item_table, item_id) VALUES (?, ?)',
      [data.item_table, data.item_id],
      (error, results) => {
        if (error) {
          return callBack(error);
        }
        return callBack(null, results);
      }
    );
  },

  allFeatureds: (callBack) => {
    let quoteList = [];
    let visualList = [];
    let finalList = {};

    pool.query('SELECT item_id, item_table FROM featured', [], (error, results) => {
      if (error) {
        return callBack(error);
      }

      results.forEach(result => {
        if (result.item_table === 'quotes') {
          quoteList.push(result.item_id);
        } else {
          visualList.push(result.item_id);
        }
      });

      pool.query(
        'SELECT is_text, quote FROM quotes WHERE id IN (?)',
        [quoteList.length ? quoteList : [0]], 
        (error, quoteResults) => {
          if (error) {
            return callBack(error);
          }

          finalList['quoteList'] = quoteResults;

          pool.query(
            'SELECT category, image_path FROM visual_assets WHERE id IN (?)',
            [visualList.length ? visualList : [0]],
            (error, visualResults) => {
              if (error) {
                return callBack(error);
              }

              finalList['visualList'] = visualResults;

              return callBack(null, finalList);
            }
          );
        }
      );
    });
  }
};
