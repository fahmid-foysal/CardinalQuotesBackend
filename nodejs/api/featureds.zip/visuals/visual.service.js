const pool = require("../../config/database");

module.exports = {
    create: (data, callBack) => {
        pool.query(
            'INSERT INTO visual_assets (category, image_path) VALUES (?, ?)',
            [data.category, data.img_path],
            (error, results) => {
                if (error) {
                    return callBack(error);
                }
                return callBack(null, results);
            }
        );
    },
    
    visualsByCategory: (category, callBack) => {
        pool.query(
            'SELECT id, image_path FROM visual_assets WHERE category = ?',
            [category],
            (error, results) => {
                if (error) {
                    return callBack(error);
                }
                return callBack(null, results);
            }
        );
    }
};