const pool = require("../../config/database");

module.exports = {
    create: (data, callBack) => {
        pool.query(
            'INSERT INTO admin (name, email, password) VALUES (?, ?, ?)',
            [data.name, data.email, data.password],
            (error, results) => {
                if (error) {
                    return callBack(error);
                }
                return callBack(null, results);
            }
        );
    },

    getUserByPhone: (email, callBack) => {
        pool.query(
            'SELECT * FROM admin WHERE email = ?',
            [email],
            (error, results) => {
                if (error) {
                    return callBack(error);
                }
                return callBack(null, results[0]);
            }
        );
    }
};
