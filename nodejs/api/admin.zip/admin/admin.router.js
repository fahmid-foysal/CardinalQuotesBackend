const { createUser, loginUser, getUserProfile } = require("./admin.controller");
const { checkToken } = require("../../middleware/auth");
const router = require("express").Router();

router.post("/register", createUser);
router.post("/login", loginUser);

// Protected route
router.get("/profile", checkToken, getUserProfile);

module.exports = router;
